import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { BluetoothProvider } from '../context/BluetoothContext';

function AppStack() {
  return (
    <>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: '#DC2626' },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      </Stack>
    </>
  );
}

export default function RootLayout() {
  return (
    <BluetoothProvider>
      <AppStack />
    </BluetoothProvider>
  );
}
