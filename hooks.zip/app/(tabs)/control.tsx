import { Ionicons } from '@expo/vector-icons';
import { useEffect, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useBluetooth } from '../../context/BluetoothContext';

export default function ControlScreen() {
  const { isConnected, sendCommand, requestStatus, telemetry } = useBluetooth();
  const [pumpActive, setPumpActive] = useState(false);

  useEffect(() => {
    setPumpActive(telemetry.pump > 0);
  }, [telemetry.pump]);

  const handleCommand = async (cmd: string) => {
    if (!isConnected) {
      Alert.alert('Erro', 'Conecte-se ao HydroBot primeiro');
      return;
    }

    await sendCommand(cmd);
  };

  const toggleMode = async () => {
    if (!isConnected) {
      Alert.alert('Erro', 'Conecte-se ao HydroBot primeiro');
      return;
    }

    await sendCommand(telemetry.mode === 'AUTO' ? 'MODE_MANUAL' : 'MODE_AUTO');
  };

  const togglePump = async () => {
    if (!isConnected) {
      Alert.alert('Erro', 'Conecte-se ao HydroBot primeiro');
      return;
    }

    await sendCommand(pumpActive ? 'PUMP_OFF' : 'PUMP_ON');
  };

  const emergencyStop = async () => {
    await handleCommand('STOP');
    await handleCommand('PUMP_OFF');
  };

  const isManualMode = telemetry.mode === 'MANUAL';

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <View style={[styles.statusBar, !isConnected && styles.statusBarDisconnected]}>
          <Ionicons
            name={isConnected ? 'radio-button-on' : 'radio-button-off'}
            size={20}
            color={isConnected ? '#10B981' : '#EF4444'}
          />
          <Text style={[styles.statusText, !isConnected && styles.statusTextDisconnected]}>
            {isConnected ? 'Conectado' : 'Desconectado'}
          </Text>
        </View>

        <View style={styles.card}>
          <View style={styles.modeHeader}>
            <View style={styles.modeInfo}>
              <Ionicons name={telemetry.mode === 'AUTO' ? 'sync' : 'hand-left'} size={28} color="#DC2626" />
              <View style={styles.modeText}>
                <Text style={styles.modeTitle}>Modo {telemetry.mode === 'AUTO' ? 'Automático' : 'Manual'}</Text>
                <Text style={styles.modeDescription}>
                  {telemetry.mode === 'AUTO' ? 'Robô controla sozinho' : 'Você controla o carrinho'}
                </Text>
              </View>
            </View>
            <TouchableOpacity
              style={[styles.modeButton, telemetry.mode === 'AUTO' && styles.modeButtonActive]}
              onPress={toggleMode}
              disabled={!isConnected}
            >
              <Text style={[styles.modeButtonText, telemetry.mode === 'AUTO' && styles.modeButtonTextActive]}>
                {telemetry.mode === 'AUTO' ? 'AUTO' : 'MANUAL'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {isManualMode && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Controle de Movimento</Text>

            <View style={styles.controlsContainer}>
              <View style={styles.controlRow}>
                <TouchableOpacity
                  style={[styles.directionButton, !isConnected && styles.disabled]}
                  onPressIn={() => handleCommand('FWD')}
                  onPressOut={() => handleCommand('STOP')}
                  disabled={!isConnected}
                >
                  <Ionicons name="arrow-up" size={32} color="#fff" />
                </TouchableOpacity>
              </View>

              <View style={styles.controlRow}>
                <TouchableOpacity
                  style={[styles.directionButton, !isConnected && styles.disabled]}
                  onPressIn={() => handleCommand('RIGHT')}
                  onPressOut={() => handleCommand('STOP')}
                  disabled={!isConnected}
                >
                  <Ionicons name="arrow-back" size={32} color="#fff" />
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.directionButton, styles.stopButton, !isConnected && styles.disabled]}
                  onPress={() => handleCommand('STOP')}
                  disabled={!isConnected}
                >
                  <Ionicons name="stop" size={32} color="#fff" />
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.directionButton, !isConnected && styles.disabled]}
                  onPressIn={() => handleCommand('LEFT')}
                  onPressOut={() => handleCommand('STOP')}
                  disabled={!isConnected}
                >
                  <Ionicons name="arrow-forward" size={32} color="#fff" />
                </TouchableOpacity>
              </View>

              <View style={styles.controlRow}>
                <TouchableOpacity
                  style={[styles.directionButton, !isConnected && styles.disabled]}
                  onPressIn={() => handleCommand('BACK')}
                  onPressOut={() => handleCommand('STOP')}
                  disabled={!isConnected}
                >
                  <Ionicons name="arrow-down" size={32} color="#fff" />
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Bomba de Água</Text>

          <View style={styles.pumpContainer}>
            <View style={styles.pumpInfo}>
              <Ionicons name="water" size={48} color={pumpActive ? '#3B82F6' : '#D1D5DB'} />
              <View style={styles.pumpText}>
                <Text style={styles.pumpStatus}>{pumpActive ? 'Ligada' : 'Desligada'}</Text>
                {pumpActive && <Text style={styles.pumpPWM}>Potência: {telemetry.pump}</Text>}
              </View>
            </View>

            <TouchableOpacity
              style={[styles.pumpButton, pumpActive && styles.pumpButtonActive, !isConnected && styles.disabled]}
              onPress={togglePump}
              disabled={!isConnected || !isManualMode}
            >
              <Ionicons name={pumpActive ? 'pause' : 'play'} size={24} color="#fff" />
              <Text style={styles.pumpButtonText}>{pumpActive ? 'Desligar' : 'Ligar'}</Text>
            </TouchableOpacity>
          </View>

        </View>

        <View style={styles.card}>
          <Text style={styles.cardTitle}>Ações Rápidas</Text>

          <TouchableOpacity
            style={[styles.actionButton, !isConnected && styles.disabled]}
            onPress={() => handleCommand('CALIBRATE')}
            disabled={!isConnected}
          >
            <Ionicons name="settings-outline" size={24} color="#DC2626" />
            <Text style={styles.actionButtonText}>Calibrar Sensores</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, !isConnected && styles.disabled]}
            onPress={requestStatus}
            disabled={!isConnected}
          >
            <Ionicons name="refresh" size={24} color="#DC2626" />
            <Text style={styles.actionButtonText}>Atualizar Status</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, styles.emergencyButton, !isConnected && styles.disabled]}
            onPress={emergencyStop}
            disabled={!isConnected}
          >
            <Ionicons name="alert-circle" size={24} color="#fff" />
            <Text style={[styles.actionButtonText, { color: '#fff' }]}>Parada de Emergência</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  content: {
    padding: 16,
  },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D1FAE5',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  statusBarDisconnected: {
    backgroundColor: '#FEE2E2',
  },
  statusText: {
    marginLeft: 8,
    fontSize: 14,
    fontWeight: '600',
    color: '#065F46',
  },
  statusTextDisconnected: {
    color: '#991B1B',
  },
  card: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  modeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  modeInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  modeText: {
    marginLeft: 12,
    flex: 1,
  },
  modeTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  modeDescription: {
    fontSize: 13,
    color: '#6B7280',
    marginTop: 2,
  },
  modeButton: {
    backgroundColor: '#E5E7EB',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  modeButtonActive: {
    backgroundColor: '#DC2626',
  },
  modeButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B7280',
  },
  modeButtonTextActive: {
    color: '#fff',
  },
  controlsContainer: {
    alignItems: 'center',
  },
  controlRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 8,
  },
  directionButton: {
    backgroundColor: '#DC2626',
    width: 70,
    height: 70,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  stopButton: {
    backgroundColor: '#991B1B',
  },
  disabled: {
    opacity: 0.45,
  },
  pumpContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pumpInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  pumpText: {
    marginLeft: 16,
  },
  pumpStatus: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
  },
  pumpPWM: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 4,
  },
  pumpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#DC2626',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  pumpButtonActive: {
    backgroundColor: '#3B82F6',
  },
  pumpButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 8,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
  },
  emergencyButton: {
    backgroundColor: '#991B1B',
    marginBottom: 0,
  },
  actionButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginLeft: 12,
  },
});
