import { Ionicons } from '@expo/vector-icons';
import type { DimensionValue } from 'react-native';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { useBluetooth } from '../../context/BluetoothContext';

function percent(value: number, max = 100): DimensionValue {
  return `${Math.max(0, Math.min(100, (value / max) * 100))}%` as DimensionValue;
}

export default function MonitorScreen() {
  const { telemetry, isConnected } = useBluetooth();

  const getWaterIcon = (level: number) => {
    if (level >= 60) return 'water';
    if (level >= 20) return 'water-outline';
    return 'alert-circle';
  };

  const getWaterColor = (level: number) => {
    if (level >= 60) return '#3B82F6';
    if (level >= 40) return '#F59E0B';
    if (level >= 20) return '#EF4444';
    return '#991B1B';
  };

  const getFireIntensityLevel = (intensity: number) => {
    if (intensity >= telemetry.fire_danger) return 'PERIGO - Muito Perto';
    if (intensity >= telemetry.fire_ideal) return 'IDEAL - Combatendo';
    if (intensity >= telemetry.fire_thresh) return 'DETECTADO - Aproximando';
    return 'NENHUM';
  };

  const getFireColor = (intensity: number) => {
    if (intensity >= telemetry.fire_danger) return '#DC2626';
    if (intensity >= telemetry.fire_ideal) return '#F59E0B';
    if (intensity >= telemetry.fire_thresh) return '#FCD34D';
    return '#D1D5DB';
  };

  const waterColor = getWaterColor(telemetry.water);
  const fireColor = getFireColor(telemetry.intensity);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        {!isConnected ? (
          <View style={styles.disconnectedCard}>
            <Ionicons name="bluetooth-outline" size={64} color="#D1D5DB" />
            <Text style={styles.disconnectedTitle}>Não Conectado</Text>
            <Text style={styles.disconnectedText}>Conecte-se ao HydroBot para ver os dados</Text>
          </View>
        ) : (
          <>
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.cardTitleRow}>
                  <Ionicons name={getWaterIcon(telemetry.water)} size={32} color={waterColor} />
                  <Text style={styles.cardTitle}>Nível de Água</Text>
                </View>
              </View>

              <View style={styles.metricContainer}>
                <Text style={[styles.metricValue, { color: waterColor }]}>{Math.round(telemetry.water)}%</Text>
                <View style={styles.progressBar}>
                  <View style={[styles.progressFill, { width: percent(telemetry.water), backgroundColor: waterColor }]} />
                </View>
                <Text style={styles.metricDescription}>
                  {telemetry.water >= 60 && 'Nível adequado'}
                  {telemetry.water >= 40 && telemetry.water < 60 && 'Nível médio'}
                  {telemetry.water >= 20 && telemetry.water < 40 && 'Nível baixo - Reabasteça'}
                  {telemetry.water < 20 && 'CRÍTICO - Reabasteça imediatamente!'}
                </Text>
              </View>
            </View>

            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.cardTitleRow}>
                  <Ionicons name="flame" size={32} color="#DC2626" />
                  <Text style={styles.cardTitle}>Detecção de Fogo</Text>
                </View>
              </View>

              <View style={styles.metricContainer}>
                {telemetry.fire ? (
                  <View style={styles.fireDetected}>
                    <Ionicons name="flame" size={48} color="#DC2626" />
                    <Text style={styles.fireDetectedText}>FOGO DETECTADO!</Text>
                  </View>
                ) : (
                  <View style={styles.fireDetected}>
                    <Ionicons name="checkmark-circle" size={48} color="#10B981" />
                    <Text style={[styles.fireDetectedText, { color: '#10B981' }]}>Nenhum fogo detectado</Text>
                  </View>
                )}

                <Text style={styles.metricLabel}>Intensidade:</Text>
                <Text style={[styles.metricValue, { color: fireColor }]}>{Math.round(telemetry.intensity)}</Text>
                <View style={styles.progressBar}>
                  <View style={[styles.progressFill, { width: percent(telemetry.intensity, 1600), backgroundColor: fireColor }]} />
                </View>

                <View style={styles.fireLevel}>
                  <Ionicons name="analytics" size={20} color={fireColor} />
                  <Text style={[styles.fireLevelText, { color: fireColor }]}>
                    {getFireIntensityLevel(telemetry.intensity)}
                  </Text>
                </View>
              </View>
            </View>

            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.cardTitleRow}>
                  <Ionicons name="speedometer" size={32} color={telemetry.pump > 0 ? '#3B82F6' : '#D1D5DB'} />
                  <Text style={styles.cardTitle}>Bomba de Água</Text>
                </View>
              </View>

              <View style={styles.metricContainer}>
                <View style={styles.pumpStatus}>
                  <View style={[styles.pumpIndicator, { backgroundColor: telemetry.pump > 0 ? '#10B981' : '#EF4444' }]} />
                  <Text style={styles.pumpStatusText}>{telemetry.pump > 0 ? 'LIGADA' : 'DESLIGADA'}</Text>
                </View>

                {telemetry.pump > 0 && (
                  <>
                    <Text style={styles.metricValue}>Potência: {telemetry.pump}</Text>
                    <View style={styles.progressBar}>
                      <View style={[styles.progressFill, { width: percent(telemetry.pump, 255), backgroundColor: '#3B82F6' }]} />
                    </View>
                    <Text style={styles.metricDescription}>Potência: {Math.round((telemetry.pump / 255) * 100)}%</Text>
                  </>
                )}
              </View>
            </View>

            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.cardTitleRow}>
                  <Ionicons name="information-circle" size={32} color="#DC2626" />
                  <Text style={styles.cardTitle}>Status do Sistema</Text>
                </View>
              </View>

              <View style={styles.infoGrid}>
                <View style={styles.infoItem}>
                  <Text style={styles.infoLabel}>Modo</Text>
                  <View style={styles.infoValueContainer}>
                    <Ionicons name={telemetry.mode === 'AUTO' ? 'sync' : 'hand-left'} size={20} color="#DC2626" />
                    <Text style={styles.infoValue}>{telemetry.mode}</Text>
                  </View>
                </View>

                <View style={styles.infoItem}>
                  <Text style={styles.infoLabel}>Velocidade</Text>
                  <Text style={styles.infoValue}>{telemetry.speed}%</Text>
                </View>

                <View style={styles.infoItem}>
                  <Text style={styles.infoLabel}>Bomba mín.</Text>
                  <Text style={styles.infoValue}>{telemetry.pwm_min}</Text>
                </View>

                <View style={styles.infoItem}>
                  <Text style={styles.infoLabel}>Bomba máx.</Text>
                  <Text style={styles.infoValue}>{telemetry.pwm_max}</Text>
                </View>
              </View>
            </View>
          </>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  content: {
    padding: 16,
  },
  disconnectedCard: {
    backgroundColor: '#fff',
    padding: 42,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 40,
  },
  disconnectedTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#6B7280',
    marginTop: 16,
  },
  disconnectedText: {
    fontSize: 14,
    color: '#9CA3AF',
    marginTop: 8,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardHeader: {
    marginBottom: 16,
  },
  cardTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#111827',
    marginLeft: 12,
    flex: 1,
  },
  metricContainer: {
    alignItems: 'center',
  },
  metricValue: {
    fontSize: 38,
    fontWeight: 'bold',
    color: '#111827',
  },
  metricLabel: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 16,
    marginBottom: 4,
  },
  metricDescription: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 12,
    textAlign: 'center',
  },
  progressBar: {
    width: '100%',
    height: 8,
    backgroundColor: '#E5E7EB',
    borderRadius: 4,
    marginTop: 16,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  pumpStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  pumpIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  pumpStatusText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  fireDetected: {
    alignItems: 'center',
    marginBottom: 16,
  },
  fireDetectedText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#DC2626',
    marginTop: 8,
  },
  fireLevel: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
  },
  fireLevelText: {
    fontSize: 13,
    fontWeight: '600',
    marginLeft: 8,
  },
  infoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  infoItem: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#F9FAFB',
    padding: 12,
    borderRadius: 8,
  },
  infoLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 4,
  },
  infoValueContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginLeft: 4,
  },
});
