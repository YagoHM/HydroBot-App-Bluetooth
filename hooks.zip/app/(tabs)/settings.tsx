import { Ionicons } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';
import { useEffect, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { TelemetryData, useBluetooth } from '../../context/BluetoothContext';

type SliderSetting = {
  key: keyof TelemetryData;
  label: string;
  command: string;
  icon: keyof typeof Ionicons.glyphMap;
  min: number;
  max: number;
  step: number;
  unit?: string;
  color: string;
  description?: string;
};

const MOVEMENT_SETTINGS: SliderSetting[] = [
  {
    key: 'speed',
    label: 'Velocidade dos Motores',
    command: 'SET_SPEED',
    icon: 'speedometer',
    min: 30,
    max: 100,
    step: 5,
    unit: '%',
    color: '#DC2626',
  },
  {
    key: 'speed_l',
    label: 'Motor Esquerdo',
    command: 'SET_SPEED_L',
    icon: 'arrow-back-circle',
    min: 30,
    max: 100,
    step: 5,
    unit: '%',
    color: '#DC2626',
  },
  {
    key: 'speed_r',
    label: 'Motor Direito',
    command: 'SET_SPEED_R',
    icon: 'arrow-forward-circle',
    min: 30,
    max: 100,
    step: 5,
    unit: '%',
    color: '#DC2626',
  },
  {
    key: 'turn_speed',
    label: 'Velocidade de Giro',
    command: 'SET_TURN_SPEED',
    icon: 'sync',
    min: 30,
    max: 100,
    step: 5,
    unit: '%',
    color: '#DC2626',
  },
  {
    key: 'motor_pwm_min',
    label: 'Força mínima motor',
    command: 'SET_MOTOR_PWM_MIN',
    icon: 'construct',
    min: 60,
    max: 200,
    step: 5,
    color: '#DC2626',
  },
  {
    key: 'kick_fwd_ms',
    label: 'Arranque frente',
    command: 'SET_KICK_FWD',
    icon: 'arrow-up-circle',
    min: 30,
    max: 300,
    step: 5,
    unit: 'ms',
    color: '#DC2626',
  },
  {
    key: 'kick_back_ms',
    label: 'Arranque ré',
    command: 'SET_KICK_BACK',
    icon: 'arrow-down-circle',
    min: 30,
    max: 300,
    step: 5,
    unit: 'ms',
    color: '#DC2626',
  },
  {
    key: 'kick_pwm',
    label: 'Força do arranque',
    command: 'SET_KICK_PWM',
    icon: 'flash',
    min: 50,
    max: 100,
    step: 5,
    unit: '%',
    color: '#DC2626',
  },
];

const PUMP_SETTINGS: SliderSetting[] = [
  {
    key: 'pwm_min',
    label: 'Força mínima',
    command: 'SET_PWM_MIN',
    icon: 'water-outline',
    min: 150,
    max: 255,
    step: 5,
    color: '#3B82F6',
    description: 'Potência inicial da bomba',
  },
  {
    key: 'pwm_max',
    label: 'Força máxima',
    command: 'SET_PWM_MAX',
    icon: 'water',
    min: 180,
    max: 255,
    step: 5,
    color: '#3B82F6',
    description: 'Potência máxima da bomba',
  },
];

const FIRE_SETTINGS: SliderSetting[] = [
  {
    key: 'fire_thresh',
    label: 'Limiar de Detecção',
    command: 'SET_FIRE_THRESH',
    icon: 'flame-outline',
    min: 80,
    max: 800,
    step: 10,
    color: '#DC2626',
  },
  {
    key: 'fire_danger',
    label: 'Intensidade de Perigo',
    command: 'SET_FIRE_DANGER',
    icon: 'warning',
    min: 800,
    max: 2400,
    step: 20,
    color: '#DC2626',
  },
  {
    key: 'fire_ideal',
    label: 'Distância Ideal',
    command: 'SET_FIRE_IDEAL',
    icon: 'locate',
    min: 400,
    max: 1600,
    step: 20,
    color: '#DC2626',
  },
];

export default function SettingsScreen() {
  const { isConnected, sendCommand, telemetry } = useBluetooth();
  const [draft, setDraft] = useState(telemetry);

  useEffect(() => {
    setDraft(telemetry);
  }, [telemetry]);

  const handleSaveSetting = async (setting: SliderSetting, value: number) => {
    if (!isConnected) {
      Alert.alert('Erro', 'Conecte-se ao HydroBot primeiro');
      return;
    }

    const rounded = Math.round(value);
    await sendCommand(`${setting.command}:${rounded}`);
  };

  const renderSlider = (setting: SliderSetting) => {
    const value = Number(draft[setting.key]) || 0;

    return (
      <View style={styles.card} key={setting.key}>
        <View style={styles.settingHeader}>
          <Ionicons name={setting.icon} size={24} color={setting.color} />
          <Text style={styles.settingTitle}>{setting.label}</Text>
        </View>

        <View style={styles.sliderContainer}>
          <Text style={[styles.sliderValue, { color: setting.color }]}>
            {Math.round(value)}
            {setting.unit ?? ''}
          </Text>
          <Slider
            style={styles.slider}
            minimumValue={setting.min}
            maximumValue={setting.max}
            step={setting.step}
            value={value}
            onValueChange={(next) => setDraft((current) => ({ ...current, [setting.key]: Math.round(next) }))}
            onSlidingComplete={(next) => handleSaveSetting(setting, next)}
            minimumTrackTintColor={setting.color}
            maximumTrackTintColor="#D1D5DB"
            thumbTintColor={setting.color}
            disabled={!isConnected}
          />
          <View style={styles.sliderLabels}>
            <Text style={styles.sliderLabel}>
              {setting.min}
              {setting.unit ?? ''}
            </Text>
            <Text style={styles.sliderLabel}>
              {setting.max}
              {setting.unit ?? ''}
            </Text>
          </View>
          {setting.description && <Text style={styles.sliderDescription}>{setting.description}</Text>}
        </View>
      </View>
    );
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <View style={[styles.statusCard, !isConnected && styles.statusCardDisconnected]}>
          <Ionicons name={isConnected ? 'checkmark-circle' : 'close-circle'} size={24} color={isConnected ? '#10B981' : '#EF4444'} />
          <Text style={[styles.statusText, !isConnected && styles.statusTextDisconnected]}>
            {isConnected ? 'HydroBot Conectado' : 'Desconectado'}
          </Text>
        </View>

        <Text style={styles.sectionTitle}>Controle de Movimento</Text>
        {MOVEMENT_SETTINGS.map(renderSlider)}

        <Text style={styles.sectionTitle}>Bomba de Água</Text>
        {PUMP_SETTINGS.map(renderSlider)}

        <Text style={styles.sectionTitle}>Sensores de Fogo</Text>
        {FIRE_SETTINGS.map(renderSlider)}

        <Text style={styles.sectionTitle}>Informações</Text>

        <View style={styles.card}>
          <TouchableOpacity style={styles.infoRow}>
            <Ionicons name="information-circle" size={24} color="#DC2626" />
            <View style={styles.infoText}>
              <Text style={styles.infoTitle}>Sobre o HydroBot</Text>
              <Text style={styles.infoValue}>Versão de apresentação</Text>
            </View>
          </TouchableOpacity>
        </View>

        <View style={styles.card}>
          <TouchableOpacity
            style={styles.infoRow}
            onPress={() =>
              Alert.alert(
                'Ajuda',
                'Comandos principais:\n\n' +
                  'Frente, ré, esquerda e direita.\n' +
                  'Parada imediata pelo botão central.\n' +
                  'Bomba liga e desliga pelo controle.\n' +
                  'Modo manual, automático e calibração.',
              )
            }
          >
            <Ionicons name="help-circle" size={24} color="#DC2626" />
            <View style={styles.infoText}>
              <Text style={styles.infoTitle}>Ajuda</Text>
              <Text style={styles.infoValue}>Toque para ver comandos</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>Projeto HydroBot</Text>
          <Text style={styles.footerSubtext}>Controle do robô bombeiro</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  content: {
    padding: 16,
  },
  statusCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#D1FAE5',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
  },
  statusCardDisconnected: {
    backgroundColor: '#FEE2E2',
  },
  statusText: {
    marginLeft: 12,
    fontSize: 16,
    fontWeight: '600',
    color: '#065F46',
  },
  statusTextDisconnected: {
    color: '#991B1B',
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#6B7280',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginTop: 16,
    marginBottom: 12,
    marginLeft: 4,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  settingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginLeft: 12,
  },
  sliderContainer: {
    paddingHorizontal: 8,
  },
  sliderValue: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  slider: {
    width: '100%',
    height: 40,
  },
  sliderLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: -8,
  },
  sliderLabel: {
    fontSize: 12,
    color: '#6B7280',
  },
  sliderDescription: {
    fontSize: 13,
    color: '#6B7280',
    textAlign: 'center',
    marginTop: 8,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  infoText: {
    flex: 1,
    marginLeft: 12,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  infoValue: {
    fontSize: 13,
    color: '#6B7280',
  },
  footer: {
    alignItems: 'center',
    marginTop: 32,
    marginBottom: 24,
  },
  footerText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6B7280',
  },
  footerSubtext: {
    fontSize: 12,
    color: '#9CA3AF',
    marginTop: 4,
  },
});
