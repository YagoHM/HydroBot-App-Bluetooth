import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, PermissionsAndroid, Platform } from 'react-native';
import { Device, State as BleState, Subscription } from 'react-native-ble-plx';
import {
  DEFAULT_TELEMETRY,
  HYDROBOT_DEVICE_NAME,
  HYDROBOT_SERVICE_UUID,
  ParsedHydroBotMessage,
  parseHydroBotMessage,
} from '../services/hydroBotProtocol';
import { hydroBotBleService } from '../services/bleService';

export type TelemetryData = typeof DEFAULT_TELEMETRY & {
  sensor_left: number;
  sensor_center: number;
  sensor_right: number;
  delta_left: number;
  delta_center: number;
  delta_right: number;
  base_left: number;
  base_center: number;
  base_right: number;
  calibrated: boolean;
};

interface BluetoothContextType {
  device: Device | null;
  isConnected: boolean;
  telemetry: TelemetryData;
  connect: (device: Device) => Promise<void>;
  disconnect: () => Promise<void>;
  sendCommand: (command: string) => Promise<void>;
  requestStatus: () => Promise<void>;
  isScanning: boolean;
  startScan: () => Promise<void>;
  stopScan: () => void;
  devices: Device[];
  lastMessage: string | null;
  lastError: string | null;
}

const INITIAL_TELEMETRY: TelemetryData = {
  ...DEFAULT_TELEMETRY,
  sensor_left: 0,
  sensor_center: 0,
  sensor_right: 0,
  delta_left: 0,
  delta_center: 0,
  delta_right: 0,
  base_left: 0,
  base_center: 0,
  base_right: 0,
  calibrated: false,
};

const BluetoothContext = createContext<BluetoothContextType | undefined>(undefined);

function isHydroBotDevice(device: Device) {
  const name = device.name ?? device.localName ?? '';
  const serviceUUIDs = device.serviceUUIDs?.map((uuid) => uuid.toLowerCase()) ?? [];
  return name.includes(HYDROBOT_DEVICE_NAME) || serviceUUIDs.includes(HYDROBOT_SERVICE_UUID);
}

async function requestBluetoothPermissions() {
  if (Platform.OS !== 'android') return true;

  const permissions =
    Number(Platform.Version) >= 31
      ? [
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        ]
      : [PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION];

  const result = await PermissionsAndroid.requestMultiple(permissions);
  return Object.values(result).every((status) => status === PermissionsAndroid.RESULTS.GRANTED);
}

function applyParsedMessage(current: TelemetryData, message: ParsedHydroBotMessage): TelemetryData {
  if (message.kind === 'telemetry') {
    return { ...current, ...message.telemetry };
  }

  if (message.event === 'mode' && (message.value === 'AUTO' || message.value === 'MANUAL')) {
    return { ...current, mode: message.value };
  }

  if (message.event === 'fire-too-close' || message.event === 'fire-fighting' || message.event === 'fire-approaching') {
    return { ...current, fire: true };
  }

  if (message.event === 'fire-out' || message.event === 'fire-lost') {
    return { ...current, fire: false };
  }

  if (message.event === 'calibrated' && message.value) {
    const [baseLeft, baseCenter, baseRight] = message.value.split(',').map((value) => Number(value.trim()));
    return {
      ...current,
      calibrated: true,
      base_left: Number.isFinite(baseLeft) ? baseLeft : current.base_left,
      base_center: Number.isFinite(baseCenter) ? baseCenter : current.base_center,
      base_right: Number.isFinite(baseRight) ? baseRight : current.base_right,
    };
  }

  if (message.event === 'calibrating') {
    return { ...current, calibrated: false };
  }

  return current;
}

export const BluetoothProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [device, setDevice] = useState<Device | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [telemetry, setTelemetry] = useState<TelemetryData>(INITIAL_TELEMETRY);
  const [devices, setDevices] = useState<Device[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [lastMessage, setLastMessage] = useState<string | null>(null);
  const [lastError, setLastError] = useState<string | null>(null);
  const scanFinished = useRef(false);
  const stateSubscription = useRef<Subscription | null>(null);

  const stopScan = () => {
    hydroBotBleService.stopScan();
    scanFinished.current = true;
    setIsScanning(false);
  };

  const startScan = async () => {
    try {
      const hasPermission = await requestBluetoothPermissions();
      if (!hasPermission) {
        Alert.alert('Permissões negadas', 'Permita o Bluetooth para conectar ao HydroBot.');
        return;
      }

      await hydroBotBleService.ensurePoweredOn();

      setDevices([]);
      setLastError(null);
      setIsScanning(true);
      scanFinished.current = false;

      hydroBotBleService.scan(
        {
          onDevice: (scannedDevice) => {
            if (!isHydroBotDevice(scannedDevice)) return;

            setDevices((current) =>
              current.some((item) => item.id === scannedDevice.id) ? current : [...current, scannedDevice],
            );
          },
          onError: (message) => {
            setLastError(message);
            setIsScanning(false);
            Alert.alert('Erro ao buscar', message);
          },
          onDone: () => {
            if (!scanFinished.current) {
              setIsScanning(false);
            }
          },
        },
        10000,
      );
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Falha ao iniciar busca Bluetooth.';
      setLastError(message);
      setIsScanning(false);
      Alert.alert('Bluetooth', message);
    }
  };

  const connect = async (selectedDevice: Device) => {
    try {
      stopScan();
      setLastError(null);
      setLastMessage(null);

      const connectedDevice = await hydroBotBleService.connect(selectedDevice);
      setDevice(connectedDevice);
      setIsConnected(true);
      setTelemetry((current) => ({ ...INITIAL_TELEMETRY, ...current }));
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Não foi possível conectar ao HydroBot.';
      setDevice(null);
      setIsConnected(false);
      setLastError(message);
      Alert.alert('Erro ao conectar', message);
    }
  };

  const disconnect = async () => {
    try {
      await hydroBotBleService.disconnect(true);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Falha ao desconectar.';
      setLastError(message);
    } finally {
      setDevice(null);
      setIsConnected(false);
    }
  };

  const sendCommand = async (command: string) => {
    if (!isConnected) {
      Alert.alert('Erro', 'Conecte-se ao HydroBot primeiro.');
      return;
    }

    try {
      await hydroBotBleService.sendCommand(command.trim() as never);
      setLastMessage(`TX: ${command.trim()}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Falha ao enviar comando.';
      setLastError(message);
      Alert.alert('Erro BLE', message);
    }
  };

  const requestStatus = () => sendCommand('GET_STATUS');

  useEffect(() => {
    const unsubscribeTelemetry = hydroBotBleService.subscribeToTelemetry((messages) => {
      for (const message of messages) {
        setLastMessage(`RX: ${message.raw}`);
        setTelemetry((current) => applyParsedMessage(current, message));

        if (message.kind === 'event' && message.event === 'error') {
          setLastError(message.raw);
        }
      }
    });

    const unsubscribeDisconnect = hydroBotBleService.subscribeToDisconnect((message) => {
      setDevice(null);
      setIsConnected(false);
      if (message) {
        setLastError(message);
      }
    });

    stateSubscription.current = hydroBotBleService.onStateChange((state) => {
      if (state === BleState.PoweredOff) {
        setDevice(null);
        setIsConnected(false);
        setLastError('Bluetooth desligado.');
      }
    });

    return () => {
      unsubscribeTelemetry();
      unsubscribeDisconnect();
      stateSubscription.current?.remove();
      hydroBotBleService.stopScan();
      void hydroBotBleService.disconnect(false);
    };
  }, []);

  const value = useMemo(
    () => ({
      device,
      isConnected,
      telemetry,
      connect,
      disconnect,
      sendCommand,
      requestStatus,
      isScanning,
      startScan,
      stopScan,
      devices,
      lastMessage,
      lastError,
    }),
    [device, isConnected, telemetry, isScanning, devices, lastMessage, lastError],
  );

  return <BluetoothContext.Provider value={value}>{children}</BluetoothContext.Provider>;
};

export const useBluetooth = () => {
  const context = useContext(BluetoothContext);
  if (!context) {
    throw new Error('useBluetooth deve ser usado dentro de BluetoothProvider');
  }
  return context;
};
